module.exports = {
  content: ["./index.html", "./index.js", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {},
  },
  plugins: [],
};
